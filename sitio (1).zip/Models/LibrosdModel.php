<?php
class LibrosdModel extends Mysql{
    protected $id, $nombre,$imagen;
    public function __construct()
    {
        parent::__construct();
    }
    public function selectLibro()
    {
        $sql = "SELECT a.id, a.autor, e.id, e.editorial, c.id, c.categoria,li.id, li.licencia, l.id, l.isbn, l.titulo, l.id_autor, l.num_pagina, l.id_editorial,l.id_categoria, l.ruta_libro,l.id_licencia, l.estado FROM autor a INNER JOIN editorial e INNER JOIN categoria c INNER JOIN licencia li INNER JOIN libro l ON a.id = l.id_autor AND e.id = l.id_editorial WHERE c.id = l.id_categoria AND li.id = l.id_licencia AND l.tipo_libro ='digital'";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectCategoria()
    {
        $sql = "SELECT * FROM categoria";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectLicencia()
    {
        $sql = "SELECT * FROM licencia";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectEditorial()
    {
        $sql = "SELECT * FROM editorial";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectAutor()
    {
        $sql = "SELECT * FROM autor";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarLibro(String $isbn, String $titulo, int $cantidad, int $autor, int $editorial, String $anio_edicion, int $num_pagina, String $descripcion, int $categoria, int $licencia, String $tipo_libro, String $imgName, String $ruta_libro)
    {
        $this->isbn = $isbn;
        $this->titulo = $titulo;
        $this->cantidad = $cantidad;
        $this->autor = $autor;
        $this->editorial = $editorial;
        $this->anio_edicion = $anio_edicion;        
        $this->num_pagina = $num_pagina;
        $this->descripcion = $descripcion;
        $this->categoria = $categoria;
        $this->licencia = $licencia;
        $this->tipo_libro = $tipo_libro;
        $this->imgName = $imgName;
        $this->ruta_libro = $ruta_libro;
        $query = "INSERT INTO libro (isbn, titulo, cantidad, id_autor, id_editorial, anio_edicion, num_pagina, descripcion, id_categoria, id_licencia, tipo_libro, imagen, ruta_libro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $data = array($this->isbn, $this->titulo, $this->cantidad, $this->autor, $this->editorial,$this->anio_edicion, $this->num_pagina, $this->descripcion,$this->categoria, $this->licencia, $this->tipo_libro, $this->imgName, $this->ruta_libro);
        $this->insert($query, $data);
        return true;
    }
    public function editLibro(int $id)
    {
        $sql = "SELECT * FROM libro WHERE id = $id";
        $res = $this->select($sql);
        return $res;
    }
    public function actualizarLibro(String $isbn, String $titulo, int $cantidad, int $autor, int $editorial, String $anio_edicion, int $num_pagina, String $descripcion, int $categoria, int $licencia, String $tipo_libro, String $imgName, String $ruta_libro, int $id)
    {
        $this->isbn = $isbn;
        $this->titulo = $titulo;
        $this->cantidad = $cantidad;
        $this->autor = $autor;
        $this->editorial = $editorial;
        $this->anio_edicion = $anio_edicion;        
        $this->num_pagina = $num_pagina;
        $this->descripcion = $descripcion;
        $this->categoria = $categoria;
        $this->licencia = $licencia;
        $this->tipo_libro = $tipo_libro;
        $this->imgName = $imgName;
        $this->ruta_libro = $ruta_libro;
        $this->id = $id;
        $query = "UPDATE libro SET isbn=?, titulo=?, cantidad=?, id_autor=?, id_editorial=?, anio_edicion=?, num_pagina=?, descripcion=?, id_categoria=?, id_licencia=?, tipo_libro=?, imagen=?, ruta_libro=? WHERE id = ?";
        $data = array($this->isbn, $this->titulo, $this->cantidad, $this->autor, $this->editorial,$this->anio_edicion, $this->num_pagina, $this->descripcion,$this->categoria, $this->licencia, $this->tipo_libro, $this->imgName, $this->ruta_libro, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoLibro(int $estado, int $id)
    {
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE libro SET estado = ? WHERE id = ?";
        $data = array($this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
    
}
