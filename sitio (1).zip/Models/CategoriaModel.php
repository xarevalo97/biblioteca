<?php
class CategoriaModel extends Mysql{
    public $id, $ruc, $nombre, $telefono, $direccion;
    public function __construct()
    {
        parent::__construct();
    }
    public function selectCategoria()
    {
        $sql = "SELECT * FROM categoria";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarCategoria(String $nombre)
    {
        $this->nombre = $nombre;
        $query = "INSERT INTO categoria(categoria) VALUES (?)";
        $data = array($this->nombre);
        $this->insert($query, $data);
        return true;
    }
    public function editCategoria(int $id)
    {
        $sql = "SELECT * FROM categoria WHERE id = $id";
        $res = $this->select($sql);
        return $res;
    }
    public function actualizarCategoria(String $nombre, int $id)
    {
        $this->nombre = $nombre;
        $this->id = $id;
        $query = "UPDATE categoria SET categoria = ? WHERE id = ?";
        $data = array($this->nombre, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoCategoria(int $estado, int $id)
    {
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE categoria SET estado = ? WHERE id = ?";
        $data = array($this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
}
?>