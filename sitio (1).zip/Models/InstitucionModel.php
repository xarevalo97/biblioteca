<?php
class InstitucionModel extends Mysql{
    public $id, $ruc, $nombre, $telefono, $direccion;
    public function __construct()
    {
        parent::__construct();
    }
    public function selectInstitucion()
    {
        $sql = "SELECT * FROM institucion";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarInstitucion(String $codigo, String $nombre, String $departamento, String $municipio)
    {
        $this->codigo = $codigo;
        $this->nombre = $nombre;
        $this->departamento = $departamento;
        $this->municipio = $municipio;
        $query = "INSERT INTO institucion(codigo, institucion, departamento, municipio) VALUES (?,?,?,?)";
        $data = array($this->codigo, $this->nombre,$this->departamento, $this->municipio);
        $this->insert($query, $data);
        return true;
    }
    public function editInstitucion(int $id)
    {
        $sql = "SELECT * FROM institucion WHERE id = $id";
        $res = $this->select($sql);
        return $res;
    }
    public function actualizarInstitucion(String $codigo, String $nombre, String $departamento, String $municipio, int $id)
    {
        $this->codigo = $codigo;
        $this->nombre = $nombre;
        $this->departamento = $departamento;
        $this->municipio = $municipio;
        $this->id = $id;
        $query = "UPDATE institucion SET codigo = ?, institucion = ?, departamento = ?, municipio = ? WHERE id = ?";
        $data = array($this->codigo, $this->nombre,$this->departamento, $this->municipio, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoInstitucion(int $estado, int $id)
    {
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE institucion SET estado = ? WHERE id = ?";
        $data = array($this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
}
?>