<?php
class HomeModel extends Mysql{
    public $usuario, $clave;
    public function __construct()
    {
        parent::__construct();
    }
    
}
?>