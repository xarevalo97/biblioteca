<?php
class GradoModel extends Mysql{
    public $id, $ruc, $nombre, $telefono, $direccion;
    public function __construct()
    {
        parent::__construct();
    }
    public function selectGrado()
    {
        $sql = "SELECT * FROM grado";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarGrado(String $nombre)
    {
        $this->nombre = $nombre;
        $query = "INSERT INTO grado(grado) VALUES (?)";
        $data = array($this->nombre);
        $this->insert($query, $data);
        return true;
    }
    public function editGrado(int $id)
    {
        $sql = "SELECT * FROM grado WHERE id = $id";
        $res = $this->select($sql);
        return $res;
    }
    public function actualizarGrado(String $nombre, int $id)
    {
        $this->nombre = $nombre;
        $this->id = $id;
        $query = "UPDATE grado SET grado = ? WHERE id = ?";
        $data = array($this->nombre, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoGrado(int $estado, int $id)
    {
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE grado SET estado = ? WHERE id = ?";
        $data = array($this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
}
?>