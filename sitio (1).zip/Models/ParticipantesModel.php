<?php
class ParticipantesModel extends Mysql{
    public function __construct()
    {
        parent::__construct();
    }
    public function selectParticipante()
    {
        $sql = "SELECT p.id, p.codigo, p.dni,p.nombre,p.edad,p.carrera,p.direccion,p.telefono,p.id_sexo,s.sexo,p.id_tipoparticipante,t.tipoparticipante,p.estado
        FROM participante p 
        INNER JOIN sexo s 
        INNER JOIN tipoparticipante t 
        WHERE s.id = p.id_sexo AND t.id = p.id_tipoparticipante";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectSexo()
    {
        $sql = "SELECT * FROM sexo";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectTipoParticipante()
    {
        $sql = "SELECT * FROM tipoparticipante";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarParticipante(String $codigo, String $dni, String $nombre,int $edad, String $carrera, String $direccion, String $telefono,int $id_sexo, int $id_tipoparticipante)
    {
        $this->codigo = $codigo;
        $this->dni = $dni;
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->carrera = $carrera;
        $this->direccion = $direccion;
        $this->telefono = $telefono;
        $this->id_sexo = $id_sexo;
        $this->id_tipoparticipante = $id_tipoparticipante;
        $query = "INSERT INTO participante(codigo, dni, nombre, edad, carrera, direccion, telefono, id_sexo, id_tipoparticipante) VALUES (?,?,?,?,?,?,?,?,?)";
        $data = array($this->codigo, $this->dni, $this->nombre, $this->edad, $this->carrera, $this->direccion, $this->telefono, $this->id_sexo, $this->id_tipoparticipante);
        $this->insert($query, $data);
        return true;
    }
    public function editParticipante(int $id)
    {
        $sql = "SELECT * FROM participante WHERE id = $id";
        $res = $this->select($sql);
        return $res;
    }
    public function actualizarParticipante(String $codigo, String $dni, String $nombre,int $edad, String $carrera, String $direccion, String $telefono,int $id_sexo, int $id_tipoparticipante, int $id)
    {
        $this->codigo = $codigo;
        $this->dni = $dni;
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->carrera = $carrera;
        $this->direccion = $direccion;
        $this->telefono = $telefono;
        $this->id_sexo = $id_sexo;
        $this->id_tipoparticipante = $id_tipoparticipante;
        $this->id = $id;
        $query = "UPDATE participante SET codigo = ?, dni = ?, nombre = ?,edad = ?, carrera = ?, direccion = ?, telefono = ?,id_sexo = ?,id_tipoparticipante = ? WHERE id = ?";
        $data = array($this->codigo, $this->dni, $this->nombre, $this->edad, $this->carrera, $this->direccion, $this->telefono, $this->id_sexo, $this->id_tipoparticipante, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoParticipante(int $estado, int $id)
    {
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE participante SET estado = ? WHERE id = ?";
        $data = array($this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function insertbatch(array $data){
        $args=array_fill(0, count($data[0]), '?');
        $query = "INSERT INTO participante(codigo,dni,nombre,edad,carrera,direccion,telefono,id_sexo,id_tipoparticipante) VALUES (".implode(',',$args).")";
		$this->insert_batch($query, $data);
		return true;
	}
}
