<?php
class AdminModel extends Mysql{
    public function __construct()
    {
        parent::__construct();
    }
    public function selectLibros()
    {
        $sql = "SELECT * FROM libro WHERE estado = 1 AND tipo_libro='fisico'";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectInstitucion()
    {
        $sql = "SELECT * FROM institucion WHERE estado = 1";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectGrado()
    {
        $sql = "SELECT * FROM grado WHERE estado = 1";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectLibrosCantidad(int $id)
    {
        $sql = "SELECT * FROM libro WHERE id = $id AND tipo_libro='fisico'";
        $res = $this->select($sql);
        return $res;
    }
    public function selectParticipantes()
    {
        $sql = "SELECT * FROM participante WHERE estado = 1";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectPrestamoCantidad()
    {
        $sql = "SELECT * FROM prestamo WHERE estado = 1";
        $res = $this->select($sql);
        return $res;
    }
    public function selectPrestamoExternoCantidad()
    {
        $sql = "SELECT * FROM prestamoexterno WHERE estado = 1";
        $res = $this->select($sql);
        return $res;
    }
    public function selectPrestamo()
    {
        $sql = "SELECT e.id, e.nombre,e.dni, l.id,l.isbn, l.titulo, p.id, p.id_participante, p.id_libro, p.fecha_prestamo, p.fecha_devolucion, p.cantidad, p.observacion, p.estado FROM participante e INNER JOIN libro l INNER JOIN prestamo p ON p.id_participante = e.id WHERE p.id_libro = l.id";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectPrestamoExterno()
    {
        $sql = "SELECT u.id, u.nombre,i.id, i.institucion,g.id, g.grado,l.id, l.titulo,
        pe.id, pe.id_usuario, pe.id_institucion, pe.id_grado, pe.responsable, pe.fecha_prestamo, pe.fecha_devolucion, pe.id_libro, pe.cantidad, pe.observacion, pe.estado 
        FROM 
        usuarios u 
        INNER JOIN prestamoexterno pe ON pe.id_usuario = u.id
        INNER JOIN institucion i ON pe.id_institucion = i.id
        INNER JOIN grado g ON pe.id_grado = g.id
        INNER JOIN libro l 
        WHERE  pe.id_libro = l.id";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarPrestamo(int $participante, int $libro,  String $fecha_prestamo, String $fecha_devolucion,int $cantidad, String $observacion)
    {
        $this->libro = $libro;
        $this->participante = $participante;
        $this->cantidad = $cantidad;
        $this->fecha_prestamo = $fecha_prestamo;
        $this->fecha_devolucion = $fecha_devolucion;
        $this->observacion = $observacion;
        $query = "INSERT INTO prestamo(id_participante, id_libro, fecha_prestamo, fecha_devolucion, cantidad ,observacion) VALUES (?,?,?,?,?,?)";
        $data = array($this->participante, $this->libro, $this->fecha_prestamo, $this->fecha_devolucion, $this->cantidad, $this->observacion);
        $this->insert($query, $data);
        return true;
    }
    public function insertarPrestamoExterno(int $usuario,int $institucion, int $grado, String $responsable, String $fecha_prestamo, String $fecha_devolucion, int $libro, int $cantidad, String $observacion)
    {
        $this->usuario = $usuario;
        $this->institucion = $institucion;
        $this->grado = $grado;
        $this->responsable = $responsable; 
        $this->fecha_prestamo = $fecha_prestamo; 
        $this->fecha_devolucion = $fecha_devolucion; 
        $this->libro = $libro;
        $this->cantidad = $cantidad; 
        $this->observacion = $observacion;
        $query = "INSERT INTO prestamoexterno (id_usuario, id_institucion, id_grado, responsable, fecha_prestamo, fecha_devolucion, id_libro, cantidad, observacion) VALUES (?,?,?,?,?,?,?,?,?)";
        $data = array($this->usuario, $this->institucion, $this->grado, $this->responsable, $this->fecha_prestamo,$this->fecha_devolucion,$this->libro,$this->cantidad, $this->observacion);
        $this->insert($query, $data);
        return true;
    }
    public function estadoPrestamo(String $obser, int $estado, int $id)
    {
        $this->obser = $obser;
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE prestamo SET observacion = ?, estado = ? WHERE id = ?";
        $data = array($this->obser, $this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoPrestamoExterno(String $obser, int $estado, int $id)
    {
        $this->obser = $obser;
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE prestamoexterno SET observacion = ?, estado = ? WHERE id = ?";
        $data = array($this->obser, $this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function actualizarCantidad(String $cantidad, int $id)
    {
        $this->cantidad = $cantidad;
        $this->id = $id;
        $query = "UPDATE libro SET cantidad = ? WHERE id = ?";
        $data = array($this->cantidad, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function selectDatos()
    {
        $sql = "SELECT * FROM configuracion";
        $res = $this->select($sql);
        return $res;
    }
    public function selectPrestamoDebe()
    {
        $sql = "SELECT e.id, e.nombre, l.id, l.titulo, p.id, p.id_participante, p.id_libro, p.fecha_prestamo, p.fecha_devolucion, p.cantidad, p.observacion, p.estado FROM participante e INNER JOIN libro l INNER JOIN prestamo p ON p.id_participante = e.id WHERE p.id_libro = l.id AND p.estado = 1";
        $res = $this->select_all($sql);
        return $res;
    }
    public function selectPrestamoExternoDebe()
    {
        $sql = " SELECT i.id, i.institucion, l.id, l.titulo, p.id, p.id_usuario, 
        p.id_libro, p.fecha_prestamo, p.fecha_devolucion, p.cantidad, p.observacion, p.estado 
        FROM institucion i INNER JOIN libro l 
        INNER JOIN prestamoexterno p ON p.id_institucion = i.id WHERE p.id_libro = l.id AND p.estado = 1";
        $res = $this->select_all($sql);
        return $res;
    }


    
}
