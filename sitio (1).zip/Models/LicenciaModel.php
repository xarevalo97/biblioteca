<?php
class LicenciaModel extends Mysql{
    public $id, $ruc, $nombre, $telefono, $direccion;
    public function __construct()
    {
        parent::__construct();
    }
    public function selectLicencia()
    {
        $sql = "SELECT * FROM licencia";
        $res = $this->select_all($sql);
        return $res;
    }
    public function insertarLicencia(String $nombre)
    {
        $this->nombre = $nombre;
        $query = "INSERT INTO licencia(licencia) VALUES (?)";
        $data = array($this->nombre);
        $this->insert($query, $data);
        return true;
    }
    public function editLicencia(int $id)
    {
        $sql = "SELECT * FROM licencia WHERE id = $id";
        $res = $this->select($sql);
        return $res;
    }
    public function actualizarLicencia(String $nombre, int $id)
    {
        $this->nombre = $nombre;
        $this->id = $id;
        $query = "UPDATE licencia SET licencia = ? WHERE id = ?";
        $data = array($this->nombre, $this->id);
        $this->update($query, $data);
        return true;
    }
    public function estadoLicencia(int $estado, int $id)
    {
        $this->estado = $estado;
        $this->id = $id;
        $query = "UPDATE licencia SET estado = ? WHERE id = ?";
        $data = array($this->estado, $this->id);
        $this->update($query, $data);
        return true;
    }
}
?>