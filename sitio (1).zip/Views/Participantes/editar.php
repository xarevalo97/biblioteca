<?php encabezado() ?>
<!-- Begin Page Content -->
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="row mt-2">
                <div class="col-lg-6 m-auto">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo base_url(); ?>participantes/modificar" method="post" enctype="multipart/form-Data" autocomplete="off">
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="codigo">DUI/NIE</label>
                                            <input type="hidden" name="id" value="<?php echo $data['participantes']['id']; ?>">
                                            <input id="codigo" class="form-control" type="text" name="codigo" value="<?php echo $data['participantes']['codigo']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="edad">Edad</label>
                                            <input id="edad" class="form-control" type="text" name="edad" value="<?php echo $data['participantes']['edad']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="sexo">Sexo</label>
                                            <select id="sexo" class="form-control" name="sexo">
                                                <?php foreach ($data['sexos'] as $sexo) { ?>
                                                    <option <?php if ($sexo['id'] == $data['participantes']['id_sexo']) {
                                                                echo 'selected';
                                                            } ?> value="<?php echo $sexo['id']; ?>"><?php echo $sexo['sexo']; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="nombre">Nombre</label>
                                            <input id="nombre" class="form-control" type="text" name="nombre" value="<?php echo $data['participantes']['nombre']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="carrera">Carrera</label>
                                            <input id="carrera" class="form-control" type="text" name="carrera" value="<?php echo $data['participantes']['carrera']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="tipoparticipante">Tipo Participante</label>
                                            <select id="tipoparticipante" class="form-control" name="tipoparticipante">
                                                <?php foreach ($data['tipoparticipantes'] as $tipoparticipante) { ?>
                                                    <option <?php if ($tipoparticipante['id'] == $data['participantes']['id_tipoparticipante']) {
                                                                echo 'selected';
                                                            } ?> value="<?php echo $tipoparticipante['id']; ?>"><?php echo $tipoparticipante['tipoparticipante']; ?></option>
                                                <?php } ?>
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="telefono">Télefono</label>
                                            <input id="telefono" class="form-control" type="text" name="telefono" value="<?php echo $data['participantes']['telefono']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="direccion">Dirección</label>
                                            <input id="direccion" class="form-control" type="text" name="direccion" value="<?php echo $data['participantes']['direccion']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit">Modificar</button>
                                            <a class="btn btn-danger" href="<?php echo base_url(); ?>participantes">Atras</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php pie() ?>