<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Sistema de biblioteca</title>
    <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/styles.css" id="theme-stylesheet">
    <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/select2.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/dataTables.bootstrap4.min.css">   
    <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/estilo.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">

</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-primary">
        <a class="navbar-brand" href="<?php echo base_url(); ?>admin/prestamointerno">Sistema de biblioteca</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
        <!-- Navbar-->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-capitalize" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['nombre']; ?> <i class="fas fa-user fa-fw"></i></a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="<?php echo base_url(); ?>usuarios/perfil">Perfil</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo base_url(); ?>usuarios/salir">Salir</a>
                </div>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <?php if ($_SESSION['rol'] == 1) { ?>
                            <a class="nav-link collapsed active" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-tasks fa-lg"></i></div>
                                Prestamo
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down fa-lg"></i></div>
                            </a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link active" href="<?php echo base_url(); ?>admin/prestamointerno">Prestamo Interno</a>
                                    <a class="nav-link active" href="<?php echo base_url(); ?>admin/prestamoexterno">Prestamo Externo</a>
                                    <a class="nav-link active" href="<?php echo base_url(); ?>institucion">Institucion</a> 
                                    <a class="nav-link active" href="<?php echo base_url(); ?>grado">Grado</a> 
                                </nav>
                            </div>
                        <?php } ?>
                        <a class="nav-link collapsed active" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-book fa-lg"></i></div>
                            Libros
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down fa-lg"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link active" href="<?php echo base_url(); ?>libros">Libros</a>
                                <a class="nav-link active" href="<?php echo base_url(); ?>autor">Autor</a>
                                <a class="nav-link active" href="<?php echo base_url(); ?>editorial">Editorial</a>
                            </nav>
                        </div>
                        <a class="nav-link active" href="<?php echo base_url(); ?>materia">
                            <div class="sb-nav-link-icon"><i class="fas fa-list fa-lg"></i>
                            </div>
                            Categoria
                        </a> <a class="nav-link active" href="<?php echo base_url(); ?>estudiantes">
                            <div class="sb-nav-link-icon"><i class="fas fa-user-graduate fa-lg"></i>
                            </div>
                            Estudiantes
                        </a>

                        <a class="nav-link collapsed active" href="<?php echo base_url(); ?>/libros" data-toggle="collapse" data-target="#collapseEst1" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-book"></i></div>
                            Libros Digitales
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down fa-lg"></i></div>
                        </a>
                        <div class="collapse" id="collapseEst1" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link active" href="<?php echo base_url(); ?>categoria">Nueva categoría</a>
                                <a class="nav-link active" href="<?php echo base_url(); ?>librosd">Nuevo Libro</a>
                                <a class="nav-link active" href="<?php echo base_url(); ?>licencia">Nueva Licencia</a>
                                <a class="nav-link active" href="<?php echo base_url(); ?>librosd/catalogo">Catalogo</a>
                            </nav>
                        </div>

                        <?php if ($_SESSION['rol'] == 1) { ?>
                            <a class="nav-link active" href="<?php echo base_url(); ?>usuarios/listar">
                                <div class="sb-nav-link-icon"><i class="fas fa-user fa-lg"></i>
                                </div>
                                Usuarios
                            </a>
                            <a class="nav-link active" href="<?php echo base_url(); ?>configuracion/listar">
                                <div class="sb-nav-link-icon"><i class="fas fa-tools fa-lg"></i>
                                </div>
                                Configuración
                            </a>
                        <?php } ?>
                        <a class="nav-link collapsed active" href="<?php echo base_url(); ?>/libros" data-toggle="collapse" data-target="#collapseEst" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-file-pdf fa-lg"></i></div>
                            Reportes
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down fa-lg"></i></div>
                        </a>
                        <div class="collapse" id="collapseEst" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link active" target="_blank" href="<?php echo base_url(); ?>admin/pdf">Prestamos Internos</a>
                                <a class="nav-link active" target="_blank" href="<?php echo base_url(); ?>admin/pdfExterno">Prestamos Externos</a>
                                <a class="nav-link active" target="_blank" href="<?php echo base_url(); ?>libros/pdf">Libros</a>
                            </nav>
                        </div>

                    </div>
                </div>
                <div class="sb-sidenav-footer bg-primary">
                    <div class="small">Síguenos en: </div>
                    <a href="https://es-la.facebook.com/inerelrosario/" class="text-white"><i class="fab fa-facebook-square"></i> Facebook</a>
                    <a href="https://www.iner.edu.sv/" class="text-danger"><i class="fab fa-chrome"></i>Sitio Web</a>
                </div>
            </nav>
        </div>

<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="container">
                        <div class="page-header">
                            <h1 class="all-tittles">Sistema bibliotecario <small>Catálogo de libros</small></h1>
                        </div>
                    </div>
                    <div class="container-fluid" style="margin: 40px 0;">
                        <div class="row">
                            <div class="col-xs-12 col-sm-4 col-md-3">
                                <img src="<?php echo base_url() ?>Assets/img/checklist.png" alt="pdf" class="img-responsive center-box" style="max-width: 110px;" width="100" height="100">
                            </div>
                            <div class="col-xs-12 col-sm-8 col-md-8 text-justify lead">
                                Bienvenido al catálogo, selecciona una categoría de la lista para empezar, si deseas buscar un libro por nombre o título has click en el icono &nbsp; <i class="zmdi zmdi-search"></i> &nbsp; que se encuentra en la barra superior
                            </div>
                        </div>
                    </div>
                    <div class="container rounded">
                        <div class="h4 font-weight-bold text-center py-3">Categorías</div>
                        <div class="row">
                            <?php foreach ($data['categorias'] as $categoria) : ?>
                                <div class="col-lg-2 col-md-2 my-lg-0 my-2">
                                    <div class="box mb-2  bg-white">
                                        <div class="d-flex justify-content-center">
                                            <div class="d-flex flex-column"><b><?php echo $categoria['categoria']; ?></b> </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="container">
                        <?php foreach ($data['libros'] as $libro) : ?>

                            <ul class="list-unstyled">
                                <li class="media">
                                    <a href="#!" class="tooltips-general" data-toggle="tooltip" data-placement="right" title="Más información del libro">
                                        <img class="media-object" src="<?php echo base_url() ?>Assets/img/book.png" alt="Libro" width="40" height="40">
                                    </a>
                                    <div class="media-body">
                                        <h4 class="media-heading">Título: <?php echo $libro['titulo']; ?></h4>
                                        <div class="pull-left">
                                            <strong>ISBN:</strong> <?php echo $libro['isbn']; ?><br>
                                            <strong>Autor:</strong> <?php echo $libro['autor']; ?><br>
                                        </div>
                                        <p class="text-center pull-right">
                                            <a class="btn btn-info btn-xs" data-toggle="collapse" href="#libro<?php echo $libro['id'] ?>" role="button" aria-expanded="false" aria-controls="libro<?php echo $libro['id']; ?>"><i class="fas fa-info-circle"></i>&nbsp;&nbsp; Más información</a>
                                            <a class="btn btn-success" href="<?php echo base_url() ?>Assets/archivos/libros/<?php echo $libro['ruta_libro']; ?>" download target="_"><i class="fas fa-cloud-download-alt"></i></a>
                                            </p>
                                            <div class="collapse" id="libro<?php echo $libro['id']; ?>">
                                            <div class="card card-body">
                                                <strong>Cantidad de Paginas: </strong><?php echo $libro['num_pagina'];  ?><br>
                                                <strong>Editorial: </strong><?php echo $libro['editorial']; ?><br>
                                                <strong>Categoria: </strong><?php echo $libro['categoria'];  ?><br>
                                                <strong>Licencia: </strong><?php echo $libro['licencia'];  ?><br>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </li>
                            </ul>
                        <?php endforeach; ?>



                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php pie() ?>