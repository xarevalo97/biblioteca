<?php encabezado() ?>
<!-- Begin Page Content -->
<div id="layoutSidenav_content">
    <main class="container mt-4">
        <h2>Carga Masiva Libros</h2>
        <hr>

        <form method="post" action="<?php echo base_url(); ?>libros/spreadsheet_import_libro" enctype="multipart/form-data">
            <div class="form-group">
                <input type="file" name="upload_file" class="form-control" placeholder="Enter Name" id="upload_file" required>
            </div>
            <div class="form-group">
                <input type="submit" name="submit" class="btn btn-primary">
            </div>
        </form>
    </main><!-- Page Content -->
<?php pie() ?>