<?php
    const BASE_URL = "https://conformable-seat.000webhostapp.com/";
    const HOST = "localhost";
    const BD = "id17709975_bibloteca";
    const DB_USER = "id17709975_root_bibloteca";
    const PASS = "D?Fra_Y6x>P]4mD>";
    const DB_CHARSET = "utf8";
?>