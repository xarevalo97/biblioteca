<?php
class Grado extends Controllers
{
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
        parent::__construct();
    }
    public function grado()
    {
        $data = $this->model->selectGrado();
        $this->views->getView($this, "listar", $data);
    }
    public function registrar()
    {
        $grado = $_POST['nombre'];
        $insert = $this->model->insertarGrado($grado);
        if ($insert) {
            header("location: " . base_url() . "grado");
            die();    
        }
    }
    public function editar()
    {
        $id = $_GET['id'];
        $data = $this->model->editGrado($id);
        if ($data == 0) {
            $this->grado();
        } else {
            $this->views->getView($this, "editar", $data);
        }
    }
    public function modificar()
    {
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $actualizar = $this->model->actualizarGrado($nombre, $id);
        if ($actualizar) {   
            header("location: " . base_url() . "grado");
            die();
        }
    }
    public function eliminar()
    {
        $id = $_POST['id'];
        $this->model->estadoGrado(0, $id);
        header("location: " . base_url() . "grado");
        die();
    }
    public function reingresar()
    {
        $id = $_POST['id'];
        $this->model->estadoGrado(1, $id);
        header("location: " . base_url() . "grado");
        die();
    }
}
?>