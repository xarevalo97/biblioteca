<?php
require 'Libraries/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Participantes extends Controllers
{
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
        parent::__construct();
    }
    public function participantes()
    {
        $participantes = $this->model->selectParticipante();
        $sexos = $this->model->selectSexo();
        $tipoparticipantes = $this->model->selectTipoParticipante();
        $data = ['participantes' => $participantes, 'sexos' => $sexos, 'tipoparticipantes' => $tipoparticipantes];
        $this->views->getView($this, "listar", $data);
    }

    public function registrar()
    {
        $codigo = $_POST['codigo'];
        $dni = $_POST['codigo'];
        $nombre = $_POST['nombre'];
        $edad = $_POST['edad'];
        $carrera = $_POST['carrera'];
        $direccion = $_POST['direccion'];
        $telefono = $_POST['telefono'];
        $sexo = $_POST['sexo'];
        $tipoparticipante = $_POST['tipoparticipante'];
        $insert = $this->model->insertarParticipante($codigo, $dni, $nombre, $edad, $carrera, $direccion, $telefono, $sexo, $tipoparticipante);
        if ($insert) {
            header("location: " . base_url() . "participantes");
            die();
        }
    }
    public function editar()
    {
        $id = $_GET['id'];
        $participantes = $this->model->editParticipante($id);
        $sexos = $this->model->selectSexo();
        $tipoparticipantes = $this->model->selectTipoParticipante();
        $data = ['participantes' => $participantes, 'sexos' => $sexos, 'tipoparticipantes' => $tipoparticipantes];

        if ($data == 0) {
            $this->participantes();
        } else {
            $this->views->getView($this, "editar", $data);
        }
    }
    public function modificar()
    {
        $id = $_POST['id'];
        $codigo = $_POST['codigo'];
        $dni = $_POST['codigo'];
        $nombre = $_POST['nombre'];
        $edad = $_POST['edad'];
        $carrera = $_POST['carrera'];
        $direccion = $_POST['direccion'];
        $telefono = $_POST['telefono'];
        $sexo = $_POST['sexo'];
        $tipoparticipante = $_POST['tipoparticipante'];
        $actualizar = $this->model->actualizarParticipante($codigo, $dni, $nombre, $edad, $carrera, $direccion, $telefono, $sexo, $tipoparticipante, $id);
        if ($actualizar) {
            header("location: " . base_url() . "participantes");
            die();
        }
    }
    public function eliminar()
    {
        $id = $_POST['id'];
        $this->model->estadoParticipante(0, $id);
        header("location: " . base_url() . "participantes");
        die();
    }
    public function reingresar()
    {
        $id = $_POST['id'];
        $this->model->estadoParticipante(1, $id);
        header("location: " . base_url() . "participantes");
        die();
    }
    public function cargamasiva()
    {
        $this->views->getView($this, "cargamasiva");
    }
    public function spreadsheet_import()
    {
        $upload_file = $_FILES['upload_file']['name'];
        $extension = pathinfo($upload_file, PATHINFO_EXTENSION);
        if ($extension == 'csv') {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        } else if ($extension == 'xls') {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
        } else {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }
        $spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
        $sheetdata = $spreadsheet->getActiveSheet()->toArray();
        //echo '<pre>';
        //print_r($sheetdata);
        $sheetcount = count($sheetdata);
        if ($sheetcount > 1) {
            $data = array();
            for ($i = 1; $i < $sheetcount; $i++) {
                $codigo = $sheetdata[$i][0];
                $dni = $sheetdata[$i][1];
                $nombre = $sheetdata[$i][2];
                $edad = $sheetdata[$i][3];
                $carrera = $sheetdata[$i][4];
                $direccion = $sheetdata[$i][5];
                $telefono = $sheetdata[$i][6];
                $id_sexo = $sheetdata[$i][7];
                $id_tipoparticipante = $sheetdata[$i][8];
                $data[] = array(
                    $codigo,
                    $dni,
                    $nombre,
                    $edad,
                    $carrera,
                    $direccion,
                    $telefono,
                    $id_sexo,
                    $id_tipoparticipante
                );
                // echo '<pre>';
                //print_r($data);

            }
            $this->model->insertbatch($data);
            header("location: " . base_url() . "participantes");
            die();
        }
        header("location: " . base_url() . "participantes");
    }
}