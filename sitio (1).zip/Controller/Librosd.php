<?php
    class Librosd extends Controllers{
        public function __construct()
        {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
            parent::__construct();

        }
        public function catalogo()
        {
            $libro = $this->model->selectLibro();
            $categorias = $this->model->selectCategoria();
            $licencias = $this->model->selectLicencia();
            $editorial = $this->model->selectEditorial();
            $autor = $this->model->selectAutor();
            $data = ['libros' => $libro, 'categorias' => $categorias,'licencias' => $licencias, 'editoriales' => $editorial, 'autores' => $autor];
            $this->views->getView($this, "catalogo", $data);
        }
        public function librosd()
        {
            $libro = $this->model->selectLibro();
            $categorias = $this->model->selectCategoria();
            $licencias = $this->model->selectLicencia();
            $editorial = $this->model->selectEditorial();
            $autor = $this->model->selectAutor();
            $data = ['libros' => $libro, 'categorias' => $categorias,'licencias' => $licencias, 'editoriales' => $editorial, 'autores' => $autor];
            $this->views->getView($this, "listar", $data);
        }
        public function registrar()
        {
            $isbn = $_POST['isbn'];
            $titulo = $_POST['titulo'];
            $autor = $_POST['autor'];
            $editorial = $_POST['editorial'];
            $anio_edicion = $_POST['anio_edicion'];
            $num_pagina = $_POST['num_pagina'];
            $descripcion = $_POST['descripcion'];
            $categoria = $_POST['categoria'];
            $licencia = $_POST['licencia'];
            $pdf = $_FILES['pdf'];
            $pdfName = $pdf['name'];
            $nombreTemp = $pdf['tmp_name'];
            $fecha = md5(date("Y-m-d h:i:s")) ."_". $pdfName;
            $destino = "Assets/archivos/libros/" . $fecha;        
            if ($pdfName == null || $pdfName == "") {
                $insert = $this->model->insertarLibro($isbn,$titulo,"1", $autor, $editorial, $anio_edicion, $num_pagina, $descripcion, $categoria, $licencia,"digital","default-avatar.png","default.pdf");
            }else{
                $insert = $this->model->insertarLibro($isbn,$titulo,"1", $autor ,$editorial, $anio_edicion, $num_pagina, $descripcion, $categoria, $licencia,"digital","default-avatar.png", $fecha);
                if ($insert) {
                    move_uploaded_file($nombreTemp, $destino);
                }
            }
            header("location: " . base_url() . "librosd");
            die();
        }
        public function editar()
        {
            $id = $_GET['id'];
            $categorias = $this->model->selectCategoria();
            $licencias = $this->model->selectLicencia();
            $editorial = $this->model->selectEditorial();
            $autor = $this->model->selectAutor();
            $libro = $this->model->editLibro($id);
            $data = ['libro' => $libro, 'categorias' => $categorias,'licencias' => $licencias, 'editoriales' => $editorial, 'autores' => $autor];
            if ($data == 0) {
                $this->librosd();
            } else {
                $this->views->getView($this, "editar", $data);
            }
        }
        public function modificar()
        {
            $id = $_POST['id'];
            $isbn = $_POST['isbn'];
            $titulo = $_POST['titulo'];
            $autor = $_POST['autor'];
            $editorial = $_POST['editorial'];
            $anio_edicion = $_POST['anio_edicion'];
            $num_pagina = $_POST['num_pagina'];
            $descripcion = $_POST['descripcion'];
            $categoria = $_POST['categoria'];
            $licencia = $_POST['licencia'];
            $pdf = $_FILES['pdf'];
            $pdfName = $pdf['name'];
            $nombreTemp = $pdf['tmp_name'];
            $fecha = md5(date("Y-m-d h:i:s")) ."_". $pdfName;
            $destino = "Assets/archivos/libros/" . $fecha;
            $pdfAntigua = $_POST['pdfanterior'];
            if ($pdfName == null || $pdfName == "") {
                $actualizar = $this->model->actualizarLibro($isbn,$titulo,"1", $autor, $editorial, $anio_edicion, $num_pagina, $descripcion, $categoria, $licencia,"digital","default-avatar.png", $pdfAntigua, $id);
            } else {
                $actualizar = $this->model->actualizarLibro($isbn,$titulo,"1", $autor ,$editorial, $anio_edicion, $num_pagina, $descripcion, $categoria, $licencia,"digital","default-avatar.png", $fecha, $id);
                if ($actualizar) {
                    move_uploaded_file($nombreTemp, $destino);
                    if ($pdfAntigua != "default.pdf") {
                        unlink("Assets/archivos/libros/" . $pdfAntigua);
                    }
                }
            }
            header("location: " . base_url() . "librosd");
            die();
        }
        public function eliminar()
        {
            $id = $_POST['id'];
            $this->model->estadoLibro(0, $id);
            header("location: " . base_url() . "librosd");
            die();
        }
        public function reingresar()
        {
            $id = $_POST['id'];
            $this->model->estadoLibro(1, $id);
            header("location: " . base_url() . "librosd");
            die();
        }
        public function pdf()
        {
            $libros = $this->model->selectLibro();
            require_once 'Libraries/pdf/fpdf.php';
            $pdf = new FPDF('P', 'mm', 'letter');
            $pdf->AddPage();
            $pdf->SetMargins(10, 10, 10);
            $pdf->SetTitle("libros");
            $pdf->SetFont('Arial', 'B', 10);
            $pdf->SetFillColor(0, 0, 0);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->Cell(196, 5, "Libros", 1, 1, 'C', 1);
            $pdf->SetTextColor(0, 0, 0);
            $pdf->Cell(11, 5, utf8_decode('N°'), 1, 0, 'L');
            $pdf->Cell(100, 5, utf8_decode('Titulo'), 1, 0, 'L');
            $pdf->Cell(70, 5, utf8_decode('Autor'), 1, 0, 'L');
            $pdf->Cell(15, 5, 'Cant.', 1, 1, 'L');
            $pdf->SetFont('Arial', '', 10);
            $contador = 1;
            foreach ($libros as $row) {
                $pdf->Cell(11, 5, $contador, 1, 0, 'L');
                $pdf->Cell(100, 5, utf8_decode($row['titulo']), 1, 0, 'L');
                $pdf->Cell(70, 5, utf8_decode($row['autor']), 1, 0, 'L');
                $pdf->Cell(15, 5, $row['cantidad'], 1, 1, 'L');
                $contador++;
            }
            $pdf->Output("libros.pdf", "I");
        }
}
