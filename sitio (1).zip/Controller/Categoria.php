<?php
class Categoria extends Controllers
{
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
        parent::__construct();
    }
    public function categoria()
    {
        $data = $this->model->selectCategoria();
        $this->views->getView($this, "listar", $data);
    }
    public function registrar()
    {
        $categoria = $_POST['nombre'];
        $insert = $this->model->insertarCategoria($categoria);
        if ($insert) {
            header("location: " . base_url() . "categoria");
            die();    
        }
    }
    public function editar()
    {
        $id = $_GET['id'];
        $data = $this->model->editCategoria($id);
        if ($data == 0) {
            $this->categoria();
        } else {
            $this->views->getView($this, "editar", $data);
        }
    }
    public function modificar()
    {
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $actualizar = $this->model->actualizarCategoria($nombre, $id);
        if ($actualizar) {   
            header("location: " . base_url() . "categoria");
            die();
        }
    }
    public function eliminar()
    {
        $id = $_POST['id'];
        $this->model->estadoCategoria(0, $id);
        header("location: " . base_url() . "categoria");
        die();
    }
    public function reingresar()
    {
        $id = $_POST['id'];
        $this->model->estadoCategoria(1, $id);
        header("location: " . base_url() . "categoria");
        die();
    }
}
?>