<?php
require 'Libraries/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Libros extends Controllers
{
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
        parent::__construct();
    }
    public function libros()
    {
        $libro = $this->model->selectLibro();
        $materias = $this->model->selectMateria();
        $editorial = $this->model->selectEditorial();
        $autor = $this->model->selectAutor();
        $data = ['libros' => $libro, 'materias' => $materias, 'editoriales' => $editorial, 'autores' => $autor];
        $this->views->getView($this, "listar", $data);
    }
    public function registrar()
    {
        $isbn = $_POST['isbn'];
        $titulo = $_POST['titulo'];
        $cantidad = $_POST['cantidad'];
        $autor = $_POST['autor'];
        $editorial = $_POST['editorial'];
        $anio_edicion = $_POST['anio_edicion'];
        $editorial = $_POST['editorial'];
        $materia = $_POST['materia'];
        $num_pagina = $_POST['num_pagina'];
        $descripcion = $_POST['descripcion'];
        $img = $_FILES['imagen'];
        $imgName = $img['name'];
        $nombreTemp = $img['tmp_name'];
        $fecha = md5(date("Y-m-d h:i:s")) . "_" . $imgName;
        $destino = "Assets/images/libros/" . $fecha;
        if ($imgName == null || $imgName == "") {
            $insert = $this->model->insertarLibro($isbn, $titulo, $cantidad, $autor, $editorial, $anio_edicion, $materia, $num_pagina, $descripcion, "default-avatar.png", "fisico");
        } else {
            $insert = $this->model->insertarLibro($isbn, $titulo, $cantidad, $autor, $editorial, $anio_edicion, $materia, $num_pagina, $descripcion, $fecha, "fisico");
            if ($insert) {
                move_uploaded_file($nombreTemp, $destino);
            }
        }
        header("location: " . base_url() . "libros");
        die();
    }
    public function editar()
    {
        $id = $_GET['id'];
        $materias = $this->model->selectMateria();
        $editorial = $this->model->selectEditorial();
        $autor = $this->model->selectAutor();
        $libro = $this->model->editLibro($id);
        $data = ['materias' => $materias, 'editoriales' => $editorial, 'autores' => $autor, 'libro' => $libro];
        if ($data == 0) {
            $this->libros();
        } else {
            $this->views->getView($this, "editar", $data);
        }
    }
    public function modificar()
    {
        $id = $_POST['id'];
        $codigo = $_POST['isbn'];
        $titulo = $_POST['titulo'];
        $cantidad = $_POST['cantidad'];
        $autor = $_POST['autor'];
        $editorial = $_POST['editorial'];
        $anio_edicion = $_POST['anio_edicion'];
        $editorial = $_POST['editorial'];
        $materia = $_POST['materia'];
        $num_pagina = $_POST['num_pagina'];
        $descripcion = $_POST['descripcion'];
        $img = $_FILES['imagen'];
        $imgName = $img['name'];
        $nombreTemp = $img['tmp_name'];
        $fecha = md5(date("Y-m-d h:i:s")) . "_" . $imgName;
        $destino = "Assets/images/libros/" . $fecha;
        $imgAntigua = $_POST['foto'];
        if ($imgName == null || $imgName == "") {
            $actualizar = $this->model->actualizarLibro($codigo, $titulo, $cantidad, $autor, $editorial, $anio_edicion, $materia, $num_pagina, $descripcion, $imgAntigua, $id);
        } else {
            $actualizar = $this->model->actualizarLibro($codigo, $titulo, $cantidad, $autor, $editorial, $anio_edicion, $materia, $num_pagina, $descripcion, $fecha, $id);
            if ($actualizar) {
                move_uploaded_file($nombreTemp, $destino);
                if ($imgAntigua != "default-avatar.png") {
                    unlink("Assets/images/libros/" . $imgAntigua);
                }
            }
        }
        header("location: " . base_url() . "libros");
        die();
    }
    public function eliminar()
    {
        $id = $_POST['id'];
        $this->model->estadoLibro(0, $id);
        header("location: " . base_url() . "libros");
        die();
    }
    public function reingresar()
    {
        $id = $_POST['id'];
        $this->model->estadoLibro(1, $id);
        header("location: " . base_url() . "libros");
        die();
    }
    public function pdf()
    {
        $datos = $this->model->selectDatos();
        $libros = $this->model->selectLibro();
        require_once 'Libraries/pdf/fpdf.php';
        $pdf = new FPDF('P', 'mm', 'letter');
        $pdf->AddPage();
        $pdf->SetMargins(10, 10, 10);
        $pdf->SetTitle("libros");
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(195, 5, utf8_decode($datos['nombre']), 0, 1, 'C');

        $pdf->image(base_url() . "/Assets/img/logo.jpg", 180, 10, 30, 30, 'JPG');
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(20, 5, utf8_decode("Teléfono: "), 0, 0, 'L');
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(20, 5, $datos['telefono'], 0, 1, 'L');
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(20, 5, utf8_decode("Dirección: "), 0, 0, 'L');
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(20, 5, utf8_decode($datos['direccion']), 0, 1, 'L');
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(20, 5, "Correo: ", 0, 0, 'L');
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(20, 5, utf8_decode($datos['correo']), 0, 1, 'L');
        $pdf->Ln();

        $pdf->SetFont('Arial', 'B', 10);
        $pdf->SetFillColor(0, 0, 0);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(196, 5, "Detalle de Libros", 1, 1, 'C', 1);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->Cell(11, 5, utf8_decode('N°'), 1, 0, 'L');
        $pdf->Cell(100, 5, utf8_decode('Titulo'), 1, 0, 'L');
        $pdf->Cell(70, 5, utf8_decode('Autor'), 1, 0, 'L');
        $pdf->Cell(15, 5, 'Cant.', 1, 1, 'L');
        $pdf->SetFont('Arial', '', 10);
        $contador = 1;
        foreach ($libros as $row) {
            $pdf->Cell(11, 5, $contador, 1, 0, 'L');
            $pdf->Cell(100, 5, utf8_decode($row['titulo']), 1, 0, 'L');
            $pdf->Cell(70, 5, utf8_decode($row['autor']), 1, 0, 'L');
            $pdf->Cell(15, 5, $row['cantidad'], 1, 1, 'L');
            $contador++;
        }
        $pdf->Output("libros.pdf", "I");
    }
    public function cargamasiva()
    {
        $this->views->getView($this,"cargamasiva");
    }
    public function spreadsheet_import_libro()
	{
		$upload_file=$_FILES['upload_file']['name'];
		$extension=pathinfo($upload_file,PATHINFO_EXTENSION);
		if($extension=='csv')
		{
			$reader= new \PhpOffice\PhpSpreadsheet\Reader\Csv();
		} else if($extension=='xls')
		{
			$reader= new \PhpOffice\PhpSpreadsheet\Reader\Xls();
		} else
		{
			$reader= new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
		}
		$spreadsheet=$reader->load($_FILES['upload_file']['tmp_name']);
		$sheetdata=$spreadsheet->getActiveSheet()->toArray();
        //echo '<pre>';
        //print_r($sheetdata);
		$sheetcount=count($sheetdata);
		if($sheetcount>1)
		{
			$data=array();
			for ($i=1; $i < $sheetcount; $i++) {
				$isbn=$sheetdata[$i][0];
				$titulo=$sheetdata[$i][1];
				$cantidad=$sheetdata[$i][2];
                $id_autor=$sheetdata[$i][3];
                $id_editorial=$sheetdata[$i][4];
                $anio_edicion=$sheetdata[$i][5];
                $id_materia=$sheetdata[$i][6];
				$num_pagina=$sheetdata[$i][7];
                $descripcion=$sheetdata[$i][8];
                $imagen=$sheetdata[$i][9];
                $tipo_libro=$sheetdata[$i][10];
				$data[]=array(
					$isbn,
					$titulo,
					$cantidad,
                    $id_autor,
                    $id_editorial,
                    $anio_edicion,
                    $id_materia,
					$num_pagina,
                    $descripcion,
                    $imagen,
                    $tipo_libro,
				);
               // echo '<pre>';
               //print_r($data);

			}
            $this->model->insertbatchlibro($data);
            header("location: " . base_url() . "libros");
			die();
			
		}
	}

}
