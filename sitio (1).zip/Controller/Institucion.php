<?php
class Institucion extends Controllers
{
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
        parent::__construct();
    }
    public function institucion()
    {
        $data = $this->model->selectInstitucion();
        $this->views->getView($this, "listar", $data);
    }
    public function registrar()
    {
        $codigo = $_POST['codigo'];
        $nombre = $_POST['nombre'];
        $departamento = $_POST['departamento'];
        $municipio = $_POST['municipio'];
        $insert = $this->model->insertarInstitucion($codigo, $nombre ,$departamento , $municipio);
        if ($insert) {
            header("location: " . base_url() . "institucion");
            die();    
        }
    }
    public function editar()
    {
        $id = $_GET['id'];
        $data = $this->model->editInstitucion($id);
        if ($data == 0) {
            $this->institucion();
        } else {
            $this->views->getView($this, "editar", $data);
        }
    }
    public function modificar()
    {
        $id = $_POST['id'];
        $codigo = $_POST['codigo'];
        $nombre = $_POST['nombre'];
        $departamento = $_POST['departamento'];
        $municipio = $_POST['municipio'];
        $actualizar = $this->model->actualizarInstitucion($codigo, $nombre ,$departamento , $municipio, $id);
        if ($actualizar) {   
            header("location: " . base_url() . "institucion");
            die();
        }
    }
    public function eliminar()
    {
        $id = $_POST['id'];
        $this->model->estadoInstitucion(0, $id);
        header("location: " . base_url() . "institucion");
        die();
    }
    public function reingresar()
    {
        $id = $_POST['id'];
        $this->model->estadoInstitucion(1, $id);
        header("location: " . base_url() . "institucion");
        die();
    }
}
?>