<?php
class Licencia extends Controllers
{
    public function __construct()
    {
        session_start();
        if (empty($_SESSION['activo'])) {
            header("location: " . base_url());
        }
        parent::__construct();
    }
    public function licencia()
    {
        $data = $this->model->selectLicencia();
        $this->views->getView($this, "listar", $data);
    }
    public function registrar()
    {
        $licencia = $_POST['nombre'];
        $insert = $this->model->insertarLicencia($licencia);
        if ($insert) {
            header("location: " . base_url() . "licencia");
            die();    
        }
    }
    public function editar()
    {
        $id = $_GET['id'];
        $data = $this->model->editLicencia($id);
        if ($data == 0) {
            $this->licencia();
        } else {
            $this->views->getView($this, "editar", $data);
        }
    }
    public function modificar()
    {
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $actualizar = $this->model->actualizarLicencia($nombre, $id);
        if ($actualizar) {   
            header("location: " . base_url() . "licencia");
            die();
        }
    }
    public function eliminar()
    {
        $id = $_POST['id'];
        $this->model->estadoLicencia(0, $id);
        header("location: " . base_url() . "licencia");
        die();
    }
    public function reingresar()
    {
        $id = $_POST['id'];
        $this->model->estadoLicencia(1, $id);
        header("location: " . base_url() . "licencia");
        die();
    }
}
?>